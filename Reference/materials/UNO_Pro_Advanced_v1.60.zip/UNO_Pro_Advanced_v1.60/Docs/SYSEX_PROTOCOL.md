# SYSEX_PROTOCOL.md

CONFIRMED: current-state read family includes 0x37 and returns 309-byte state captures in studied cases. Bootloader SysEx is documented in raw research and must never be sent during normal editor testing.

CAPTURE-CONFIRMED ROLE / WRITE STILL LOCKED: `0x28` appears in the real STORE workflow as a 304-byte Editor→UNO bulk preset-state write. Its serialized state body matches the `0x37` representation almost completely, but it is not a full sequence read and no runtime writer is enabled. `0x36` remains an external/reverse-engineering current-buffer-load candidate and is not hardware-confirmed in this project.

See `UNO_TEST_DATA_ALL.md` for captures/evidence.

## Preset catalog/name read — CONFIRMED 2026-09-08
Request slot N (1..256): `F0 00 21 1A 02 03 24 01 <bank> <program> F7`, where zero-based slot is split as `<bank>=n//128`, `<program>=n%128`. Real responses are 43 bytes and carry command byte `0x24` plus ASCII preset name. This is now safe for read-only hardware catalog acquisition.

## Hardware preset-change sync — CONFIRMED 2026-09-08
Real UNO change: Program Change -> `0x32` notification -> official Editor `0x37` read -> 309-byte state response -> ~0.5 s -> `0x24` name read. Custom editor may mirror these read-only requests. Exact full semantic decoding of every field in the 309-byte state packet is still incomplete; only confirmed fields may be applied.


## 0x37 current-state decode update — 2026-09-09
Transport remains confirmed: request `F0 00 21 1A 02 03 37 00 00 F7`, 309-byte response beginning `F0 00 21 1A 02 03 00 37 00 00`.

The full hardware sweep established observable bit masks for 83 known preset CC controls. v1.52 does not infer a generic serializer yet; it uses exact signatures observed during the sweep. If a factory/current state contains a signature not present in the sweep, that field is skipped instead of approximated. This is intentional because hardware knob resolution and mode-dependent fields may expose states not reachable in one MIDI-CC sweep.

Do not treat CC7/CC110/CC111/CC112 no-change results as proof that those controls are not stored. Their mapping remains PENDING.


## `.unosyp` / `0x37` state equivalence — 2026-09-10
1. `.unosyp` byte 0 is raw state byte 0.
2. `.unosyp` bytes 1..296 are 296 seven-bit values = 2072 bits = exactly 259 raw bytes.
3. Prepending file byte 0 yields the same 260-byte raw state represented by a 309-byte `0x37` reply.
4. `0x37` packs those 260 bytes with six leading pad bits into 298 seven-bit payload bytes.
5. This equivalence is used read-only to decode LOCAL binary presets through the existing exact-observed state LUT.

## ARP live SysEx — 2026-09-10
1. UNO→Editor `0x3E 00 00 <value>`: Direction values 0..9.
2. UNO→Editor `0x3E 00 01 <value>`: Range values 1..4.
3. UNO→Editor `0x3E 00 02 <3-byte mask>`: 16-step Pattern.
4. Editor→UNO Pattern: `F0 00 21 1A 02 03 3C 00 02 <mask0> <mask1> <mask2> F7`.
5. ARP ON/OFF command remains unknown; do not infer one.

## Hardware-sequence boundary
Existing captures contain no large UNO→Editor response carrying all 64 sequencer steps. The only large hardware reply observed is the 309-byte `0x37` current state. Therefore Program Change/`0x32` -> `0x37` -> `0x24` is not sufficient to construct a complete hardware preset cache with sequence.
